export class CookieObserverWorker {
    constructor() {
        this.listener = null;
    }
    start(handler) {
        if (this.listener) {
            return;
        }
        this.listener = (changeInfo) => {
            void handler(changeInfo);
        };
        chrome.cookies.onChanged.addListener(this.listener);
    }
    stop() {
        if (!this.listener) {
            return;
        }
        chrome.cookies.onChanged.removeListener(this.listener);
        this.listener = null;
    }
}
