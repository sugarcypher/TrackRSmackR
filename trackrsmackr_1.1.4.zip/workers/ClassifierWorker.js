export class ClassifierWorker {
    constructor(policyEngine) {
        this.policyEngine = policyEngine;
    }
    classify(cookie, options) {
        return this.policyEngine.evaluate(cookie, options);
    }
}
