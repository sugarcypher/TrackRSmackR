import { JarType } from './CookieJarWorker.js';
const STORAGE_KEYS = [
    'policyInvariantFloorMode',
    'policyInvariantDomainBlocklist',
    'policyInvariantEnforcePersona',
    'uniformPersonaEnabled',
    'personaEntropyNormalizationEnabled',
    'personaScriptBlocklistEnabled'
];
function normalizeDomain(value) {
    return value.trim().toLowerCase().replace(/^\.+/, '');
}
function normalizeBlocklist(raw) {
    if (!Array.isArray(raw)) {
        return [];
    }
    return Array.from(new Set(raw
        .filter((value) => typeof value === 'string')
        .map((value) => normalizeDomain(value))
        .filter((value) => value.length > 0)));
}
function domainMatches(domain, pattern) {
    const normalizedDomain = normalizeDomain(domain);
    const normalizedPattern = normalizeDomain(pattern);
    return (normalizedDomain === normalizedPattern ||
        normalizedDomain.endsWith(`.${normalizedPattern}`) ||
        normalizedPattern.endsWith(`.${normalizedDomain}`));
}
export class PolicyInvariantWorker {
    constructor() {
        this.floorMode = 'BALANCED';
        this.blocklist = [];
        this.enforcePersona = true;
        this.listenerAttached = false;
    }
    async init() {
        const state = (await chrome.storage.local.get([...STORAGE_KEYS]));
        this.floorMode = state.policyInvariantFloorMode === 'STRICT' ? 'STRICT' : 'BALANCED';
        this.blocklist = normalizeBlocklist(state.policyInvariantDomainBlocklist);
        this.enforcePersona = state.policyInvariantEnforcePersona !== false;
        await this.persist();
        await this.enforcePersonaInvariants(state);
        this.attachListener();
    }
    apply(cookie, decision) {
        let nextDecision = decision;
        const signals = [];
        if (this.blocklist.some((pattern) => domainMatches(cookie.domain, pattern))) {
            nextDecision = {
                action: 'QUARANTINE',
                reason: 'Policy invariant: domain blocklist enforcement',
                targetJar: JarType.QUARANTINE
            };
            signals.push('Policy invariant: domain blocklist');
        }
        if (this.floorMode === 'STRICT' && nextDecision.action === 'DECAY') {
            nextDecision = {
                action: 'QUARANTINE',
                reason: 'Policy invariant: strict floor mode',
                targetJar: JarType.QUARANTINE
            };
            signals.push('Policy invariant: strict floor');
        }
        return {
            decision: nextDecision,
            signals
        };
    }
    getFloorMode() {
        return this.floorMode;
    }
    setStateForTesting(state) {
        if (state.floorMode) {
            this.floorMode = state.floorMode;
        }
        if (state.blocklist) {
            this.blocklist = normalizeBlocklist(state.blocklist);
        }
        if (typeof state.enforcePersona === 'boolean') {
            this.enforcePersona = state.enforcePersona;
        }
    }
    async enforcePersonaInvariants(state) {
        if (!this.enforcePersona) {
            return;
        }
        const updates = {};
        if (state.uniformPersonaEnabled === false) {
            updates.uniformPersonaEnabled = true;
        }
        if (state.personaEntropyNormalizationEnabled === false) {
            updates.personaEntropyNormalizationEnabled = true;
        }
        if (state.personaScriptBlocklistEnabled === false) {
            updates.personaScriptBlocklistEnabled = true;
        }
        if (Object.keys(updates).length > 0) {
            await chrome.storage.local.set(updates);
        }
    }
    attachListener() {
        if (this.listenerAttached) {
            return;
        }
        chrome.storage.onChanged.addListener((changes, areaName) => {
            if (areaName !== 'local') {
                return;
            }
            if (changes.policyInvariantFloorMode) {
                const value = changes.policyInvariantFloorMode.newValue;
                this.floorMode = value === 'STRICT' ? 'STRICT' : 'BALANCED';
            }
            if (changes.policyInvariantDomainBlocklist) {
                this.blocklist = normalizeBlocklist(changes.policyInvariantDomainBlocklist.newValue);
            }
            if (changes.policyInvariantEnforcePersona) {
                this.enforcePersona = changes.policyInvariantEnforcePersona.newValue !== false;
            }
            if (this.enforcePersona &&
                (changes.uniformPersonaEnabled ||
                    changes.personaEntropyNormalizationEnabled ||
                    changes.personaScriptBlocklistEnabled)) {
                void this.enforcePersonaInvariants({
                    uniformPersonaEnabled: changes.uniformPersonaEnabled?.newValue,
                    personaEntropyNormalizationEnabled: changes.personaEntropyNormalizationEnabled
                        ?.newValue,
                    personaScriptBlocklistEnabled: changes.personaScriptBlocklistEnabled
                        ?.newValue
                });
            }
            void this.persist();
        });
        this.listenerAttached = true;
    }
    async persist() {
        await chrome.storage.local.set({
            policyInvariantFloorMode: this.floorMode,
            policyInvariantDomainBlocklist: this.blocklist,
            policyInvariantEnforcePersona: this.enforcePersona
        });
    }
}
