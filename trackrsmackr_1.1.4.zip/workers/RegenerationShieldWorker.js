const STORAGE_KEYS = [
    'antiRegenerationEnabled',
    'aggressiveSetCookieStripEnabled',
    'regenerationEscalationThreshold',
    'regenerationLedger',
    'regenerativeBlocklist'
];
const DEFAULT_THRESHOLD = 2;
const MIN_THRESHOLD = 1;
const MAX_THRESHOLD = 20;
const RULE_ID_BASE = 870000;
const MAX_STRIP_RULES = 200;
function normalizeDomain(domain) {
    return domain.trim().toLowerCase().replace(/^\.+/, '');
}
function normalizeKey(domain, name) {
    return `${normalizeDomain(domain)}|${name.trim().toLowerCase()}`;
}
function escapeRegex(text) {
    return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
function clampThreshold(value) {
    if (!Number.isFinite(value)) {
        return DEFAULT_THRESHOLD;
    }
    return Math.min(MAX_THRESHOLD, Math.max(MIN_THRESHOLD, Math.floor(value)));
}
export class RegenerationShieldWorker {
    constructor() {
        this.enabled = true;
        this.aggressiveStripEnabled = true;
        this.escalationThreshold = DEFAULT_THRESHOLD;
        this.ledger = {};
        this.blocklist = {};
        this.storageListenerAttached = false;
    }
    async init() {
        const data = (await chrome.storage.local.get([...STORAGE_KEYS]));
        this.enabled = data.antiRegenerationEnabled !== false;
        this.aggressiveStripEnabled = data.aggressiveSetCookieStripEnabled !== false;
        this.escalationThreshold = clampThreshold(data.regenerationEscalationThreshold);
        this.ledger = data.regenerationLedger ?? {};
        this.blocklist = data.regenerativeBlocklist ?? {};
        await this.persistState();
        await this.syncSetCookieStripRules();
        this.attachStorageListener();
    }
    async observe(cookie) {
        if (!this.enabled) {
            return { forceBlock: false };
        }
        const now = Date.now();
        const key = normalizeKey(cookie.domain, cookie.name);
        const entry = this.ensureLedgerEntry(key, cookie, now);
        entry.observations += 1;
        entry.lastObservedAt = now;
        if (typeof entry.lastRemovalAt === 'number' && now > entry.lastRemovalAt) {
            entry.regenerationEvents += 1;
            entry.lastRegeneratedAt = now;
        }
        const existingBlock = this.blocklist[key];
        if (existingBlock) {
            existingBlock.lastSeenAt = now;
            existingBlock.hits += 1;
            entry.permanentBlock = true;
            await this.persistState();
            return { forceBlock: true, signal: 'Regeneration denylist hit' };
        }
        if (!entry.permanentBlock &&
            (entry.regenerationEvents >= this.escalationThreshold ||
                entry.blockActions >= this.escalationThreshold)) {
            entry.permanentBlock = true;
            entry.escalatedAt = now;
            this.blocklist[key] = this.buildBlocklistEntry(entry, 'Auto-escalated: regenerative cookie pattern');
            await this.persistState();
            await this.syncSetCookieStripRules();
            return { forceBlock: true, signal: 'Regeneration escalation: permanent block' };
        }
        await this.persistState();
        return { forceBlock: false };
    }
    async recordEnforcement(cookie, decision, outcome) {
        if (!this.enabled) {
            return { escalated: false };
        }
        const now = Date.now();
        const key = normalizeKey(cookie.domain, cookie.name);
        const entry = this.ensureLedgerEntry(key, cookie, now);
        if (outcome === 'REMOVED' ||
            outcome === 'REMOVED_AND_QUARANTINED' ||
            outcome === 'DECAY_EXECUTED') {
            entry.removalActions += 1;
            entry.lastRemovalAt = now;
        }
        if (decision.action === 'BLOCK' || decision.action === 'QUARANTINE') {
            entry.blockActions += 1;
        }
        let escalated = false;
        if (!entry.permanentBlock &&
            (entry.regenerationEvents >= this.escalationThreshold ||
                entry.blockActions >= this.escalationThreshold)) {
            entry.permanentBlock = true;
            entry.escalatedAt = now;
            this.blocklist[key] = this.buildBlocklistEntry(entry, 'Auto-escalated: repeated block/quarantine regeneration');
            escalated = true;
        }
        await this.persistState();
        if (escalated) {
            await this.syncSetCookieStripRules();
            return {
                escalated: true,
                signal: `Regeneration escalation: ${entry.domain}/${entry.name} moved to permanent block`
            };
        }
        return { escalated: false };
    }
    async recordDecayExecution(cookie) {
        if (!this.enabled) {
            return;
        }
        const now = Date.now();
        const key = normalizeKey(cookie.domain, cookie.name);
        const entry = this.ensureLedgerEntry(key, cookie, now);
        entry.removalActions += 1;
        entry.lastRemovalAt = now;
        await this.persistState();
    }
    ensureLedgerEntry(key, cookie, now) {
        const existing = this.ledger[key];
        if (existing) {
            return existing;
        }
        const created = {
            key,
            domain: normalizeDomain(cookie.domain),
            name: cookie.name,
            observations: 0,
            regenerationEvents: 0,
            removalActions: 0,
            blockActions: 0,
            lastObservedAt: now,
            permanentBlock: false
        };
        this.ledger[key] = created;
        return created;
    }
    buildBlocklistEntry(entry, reason) {
        const now = Date.now();
        return {
            key: entry.key,
            domain: entry.domain,
            name: entry.name,
            reason,
            firstSeenAt: entry.lastObservedAt || now,
            lastSeenAt: now,
            hits: Math.max(entry.regenerationEvents, entry.blockActions, 1),
            permanentBlock: true
        };
    }
    async persistState() {
        await chrome.storage.local.set({
            antiRegenerationEnabled: this.enabled,
            aggressiveSetCookieStripEnabled: this.aggressiveStripEnabled,
            regenerationEscalationThreshold: this.escalationThreshold,
            regenerationLedger: this.ledger,
            regenerativeBlocklist: this.blocklist
        });
    }
    attachStorageListener() {
        if (this.storageListenerAttached) {
            return;
        }
        chrome.storage.onChanged.addListener((changes, areaName) => {
            if (areaName !== 'local') {
                return;
            }
            let needsRuleSync = false;
            let needsPersist = false;
            if (changes.antiRegenerationEnabled) {
                this.enabled = changes.antiRegenerationEnabled.newValue !== false;
                needsPersist = true;
            }
            if (changes.aggressiveSetCookieStripEnabled) {
                this.aggressiveStripEnabled = changes.aggressiveSetCookieStripEnabled.newValue !== false;
                needsRuleSync = true;
                needsPersist = true;
            }
            if (changes.regenerationEscalationThreshold) {
                this.escalationThreshold = clampThreshold(Number(changes.regenerationEscalationThreshold.newValue));
                needsPersist = true;
            }
            if (changes.regenerativeBlocklist) {
                this.blocklist = changes.regenerativeBlocklist.newValue ?? {};
                needsRuleSync = true;
            }
            if (changes.regenerationLedger) {
                this.ledger = changes.regenerationLedger.newValue ?? {};
            }
            if (needsPersist) {
                void this.persistState();
            }
            if (needsRuleSync) {
                void this.syncSetCookieStripRules();
            }
        });
        this.storageListenerAttached = true;
    }
    async syncSetCookieStripRules() {
        if (!chrome.declarativeNetRequest) {
            return;
        }
        const ruleIds = await this.getManagedDynamicRuleIds();
        if (!this.aggressiveStripEnabled || !this.enabled) {
            if (ruleIds.length === 0) {
                return;
            }
            await this.updateDynamicRules(ruleIds, []);
            return;
        }
        const domains = Array.from(new Set(Object.values(this.blocklist).map((entry) => normalizeDomain(entry.domain))))
            .filter((domain) => domain.length > 0)
            .slice(0, MAX_STRIP_RULES);
        const rules = domains.map((domain, index) => ({
            id: RULE_ID_BASE + index,
            priority: 1,
            action: {
                type: chrome.declarativeNetRequest.RuleActionType.MODIFY_HEADERS,
                responseHeaders: [
                    {
                        header: 'set-cookie',
                        operation: chrome.declarativeNetRequest.HeaderOperation.REMOVE
                    }
                ]
            },
            condition: {
                regexFilter: `^https?:\\/\\/([^\\/]+\\.)?${escapeRegex(domain)}\\/`,
                resourceTypes: [
                    chrome.declarativeNetRequest.ResourceType.MAIN_FRAME,
                    chrome.declarativeNetRequest.ResourceType.SUB_FRAME,
                    chrome.declarativeNetRequest.ResourceType.XMLHTTPREQUEST,
                    chrome.declarativeNetRequest.ResourceType.SCRIPT,
                    chrome.declarativeNetRequest.ResourceType.IMAGE,
                    chrome.declarativeNetRequest.ResourceType.FONT,
                    chrome.declarativeNetRequest.ResourceType.STYLESHEET,
                    chrome.declarativeNetRequest.ResourceType.MEDIA,
                    chrome.declarativeNetRequest.ResourceType.OTHER
                ]
            }
        }));
        await this.updateDynamicRules(ruleIds, rules);
    }
    async getManagedDynamicRuleIds() {
        if (!chrome.declarativeNetRequest || !chrome.declarativeNetRequest.getDynamicRules) {
            return [];
        }
        const rules = await new Promise((resolve) => {
            chrome.declarativeNetRequest.getDynamicRules((items) => resolve(items ?? []));
        });
        return rules
            .map((rule) => rule.id)
            .filter((id) => id >= RULE_ID_BASE && id < RULE_ID_BASE + MAX_STRIP_RULES);
    }
    async updateDynamicRules(removeRuleIds, addRules) {
        if (!chrome.declarativeNetRequest || !chrome.declarativeNetRequest.updateDynamicRules) {
            return;
        }
        await new Promise((resolve) => {
            chrome.declarativeNetRequest.updateDynamicRules({
                removeRuleIds,
                addRules
            }, () => {
                if (chrome.runtime?.lastError) {
                    console.warn('RegenerationShieldWorker dynamic rule update failed:', chrome.runtime.lastError.message);
                }
                resolve();
            });
        });
    }
}
