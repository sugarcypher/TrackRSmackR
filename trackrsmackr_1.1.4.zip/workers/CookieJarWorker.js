import { CryptoUtils } from '../utils/CryptoUtils.js';
export var JarType;
(function (JarType) {
    JarType["VAULT"] = "VAULT";
    JarType["QUARANTINE"] = "QUARANTINE";
})(JarType || (JarType = {}));
export class CookieJarWorker {
    constructor() {
        this.vaultKey = null;
        this.quarantineKey = null;
        this.sessionApprovedDomains = new Set();
    }
    static entryId(domain, name) {
        return `${domain}|${name}`;
    }
    approveForSession(domain) {
        this.sessionApprovedDomains.add(domain);
    }
    async approvePermanently(domain) {
        this.sessionApprovedDomains.add(domain);
        const data = (await chrome.storage.local.get('allowlist'));
        const existing = Array.isArray(data.allowlist)
            ? data.allowlist.filter((entry) => typeof entry === 'string')
            : [];
        if (!existing.includes(domain)) {
            existing.push(domain);
            await chrome.storage.local.set({ allowlist: existing });
        }
    }
    isSessionApproved(domain) {
        return this.sessionApprovedDomains.has(domain);
    }
    sessionApprovedCount() {
        return this.sessionApprovedDomains.size;
    }
    async init() {
        const storedKeyData = (await chrome.storage.local.get('vaultKey'));
        if (Array.isArray(storedKeyData.vaultKey) && storedKeyData.vaultKey.length > 0) {
            this.vaultKey = await CryptoUtils.importKey(Uint8Array.from(storedKeyData.vaultKey));
        }
        else {
            this.vaultKey = await CryptoUtils.generateKey();
            const exported = await CryptoUtils.exportKey(this.vaultKey);
            await chrome.storage.local.set({ vaultKey: Array.from(exported) });
        }
        if (!this.quarantineKey) {
            this.quarantineKey = await CryptoUtils.generateKey();
        }
    }
    async jarCookie(cookie, type) {
        const key = type === JarType.VAULT ? this.vaultKey : this.quarantineKey;
        if (!key) {
            throw new Error(`Key for ${type} not initialized.`);
        }
        const encryptedValue = await CryptoUtils.encrypt(cookie.value, key);
        const entry = {
            id: CookieJarWorker.entryId(cookie.domain, cookie.name),
            domain: cookie.domain,
            name: cookie.name,
            encryptedValue,
            createdAt: Date.now(),
            expiry: Date.now() + (type === JarType.QUARANTINE ? 30000 : 86400000),
            jarType: type
        };
        const storeKey = type === JarType.VAULT ? 'vaultStore' : 'quarantineStore';
        const data = (await chrome.storage.local.get(storeKey));
        const store = (data[storeKey] ?? {});
        store[entry.id] = entry;
        await chrome.storage.local.set({ [storeKey]: store });
        return entry.id;
    }
    async retrieveFromVault(domain, name) {
        if (!this.vaultKey) {
            return null;
        }
        const id = CookieJarWorker.entryId(domain, name);
        const data = (await chrome.storage.local.get('vaultStore'));
        const entry = data.vaultStore?.[id];
        if (!entry || entry.jarType !== JarType.VAULT) {
            return null;
        }
        try {
            return await CryptoUtils.decrypt(entry.encryptedValue, this.vaultKey);
        }
        catch (error) {
            console.error('Decryption failed for Vault entry', error);
            return null;
        }
    }
    async smash(id, type) {
        const storeKey = type === JarType.VAULT ? 'vaultStore' : 'quarantineStore';
        const data = (await chrome.storage.local.get(storeKey));
        const store = (data[storeKey] ?? {});
        if (store[id]) {
            delete store[id];
            await chrome.storage.local.set({ [storeKey]: store });
        }
    }
}
