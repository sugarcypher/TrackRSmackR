const DECAY_ALARM_PREFIX = 'trackr-smackr-decay:';
export class TimerDecayWorker {
    constructor() {
        this.smashHandler = null;
        this.pendingActions = new Map();
        this.initialized = false;
    }
    init(smashHandler) {
        this.smashHandler = smashHandler;
        if (this.initialized) {
            return;
        }
        chrome.alarms.onAlarm.addListener((alarm) => {
            if (!alarm.name.startsWith(DECAY_ALARM_PREFIX) || !this.smashHandler) {
                return;
            }
            const entryId = alarm.name.slice(DECAY_ALARM_PREFIX.length);
            const pendingAction = this.pendingActions.get(entryId);
            if (pendingAction) {
                this.pendingActions.delete(entryId);
                void pendingAction();
                return;
            }
            void this.smashHandler(entryId);
        });
        this.initialized = true;
    }
    scheduleSmash(entryId, delayMs) {
        this.pendingActions.delete(entryId);
        const safeDelayMs = Math.max(1000, delayMs);
        chrome.alarms.create(`${DECAY_ALARM_PREFIX}${entryId}`, {
            when: Date.now() + safeDelayMs
        });
    }
    scheduleAction(entryId, delayMs, action) {
        this.pendingActions.set(entryId, action);
        const safeDelayMs = Math.max(1000, delayMs);
        chrome.alarms.create(`${DECAY_ALARM_PREFIX}${entryId}`, {
            when: Date.now() + safeDelayMs
        });
    }
}
