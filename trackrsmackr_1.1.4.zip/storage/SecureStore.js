export class SecureStore {
    constructor(key) {
        this.key = key;
    }
    async load(defaultValue) {
        const data = (await chrome.storage.local.get(this.key));
        return data[this.key] ?? defaultValue;
    }
    async save(value) {
        await chrome.storage.local.set({ [this.key]: value });
    }
}
