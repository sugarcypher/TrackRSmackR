import { SecureStore } from './SecureStore.js';
export class QuarantineStore {
    constructor() {
        this.store = new SecureStore('quarantineStore');
    }
    async getAll() {
        return this.store.load({});
    }
    async remove(id) {
        const entries = await this.store.load({});
        if (!(id in entries)) {
            return;
        }
        delete entries[id];
        await this.store.save(entries);
    }
}
