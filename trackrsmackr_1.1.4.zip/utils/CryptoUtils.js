/**
 * SECURITY LAYER: AES-GCM Encryption
 * Uses the Web Crypto API to ensure all sensitive cookie values are encrypted at rest.
 */
export class CryptoUtils {
    static async generateKey() {
        return crypto.subtle.generateKey({ name: this.ALGORITHM, length: this.KEY_LENGTH }, true, ['encrypt', 'decrypt']);
    }
    static async exportKey(key) {
        return new Uint8Array(await crypto.subtle.exportKey('raw', key));
    }
    static async importKey(keyData) {
        const rawKey = new Uint8Array(keyData);
        return crypto.subtle.importKey('raw', rawKey, { name: this.ALGORITHM }, true, [
            'encrypt',
            'decrypt'
        ]);
    }
    static async encrypt(data, key) {
        const iv = crypto.getRandomValues(new Uint8Array(this.IV_LENGTH));
        const encodedData = new TextEncoder().encode(data);
        const ciphertext = await crypto.subtle.encrypt({ name: this.ALGORITHM, iv }, key, encodedData);
        const combined = new Uint8Array(iv.length + ciphertext.byteLength);
        combined.set(iv);
        combined.set(new Uint8Array(ciphertext), iv.length);
        return this.arrayBufferToBase64(combined);
    }
    static async decrypt(encryptedData, key) {
        const combined = this.base64ToArrayBuffer(encryptedData);
        if (combined.length <= this.IV_LENGTH) {
            throw new Error('Encrypted payload is too short.');
        }
        const iv = combined.slice(0, this.IV_LENGTH);
        const ciphertext = combined.slice(this.IV_LENGTH);
        const decrypted = await crypto.subtle.decrypt({ name: this.ALGORITHM, iv }, key, ciphertext);
        return new TextDecoder().decode(decrypted);
    }
    static arrayBufferToBase64(buffer) {
        let binary = '';
        for (const byte of buffer) {
            binary += String.fromCharCode(byte);
        }
        return btoa(binary);
    }
    static base64ToArrayBuffer(base64) {
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i += 1) {
            bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
    }
}
CryptoUtils.ALGORITHM = 'AES-GCM';
CryptoUtils.KEY_LENGTH = 256;
CryptoUtils.IV_LENGTH = 12;
