import { PERSONA_PROFILES, getPersonaByIndex } from './PersonaProfiles.js';
const INSTALL_ID_KEY = 'trackrsmackrInstallId';
const ASSIGNED_PERSONA_KEY = 'trackrsmackrAssignedPersona';
let cachedInstallId = null;
let cachedPersonaIndex = null;
export async function getOrCreateInstallId() {
    if (cachedInstallId !== null) {
        return cachedInstallId;
    }
    const stored = (await chrome.storage.local.get(INSTALL_ID_KEY));
    if (typeof stored[INSTALL_ID_KEY] === 'string' && stored[INSTALL_ID_KEY].length > 0) {
        cachedInstallId = stored[INSTALL_ID_KEY];
        return cachedInstallId;
    }
    const fresh = generateInstallId();
    await chrome.storage.local.set({ [INSTALL_ID_KEY]: fresh });
    cachedInstallId = fresh;
    return fresh;
}
export async function getAssignedPersonaIndex() {
    if (cachedPersonaIndex !== null) {
        return cachedPersonaIndex;
    }
    const installId = await getOrCreateInstallId();
    cachedPersonaIndex = hashToIndex(installId, PERSONA_PROFILES.length);
    return cachedPersonaIndex;
}
export async function getAssignedPersona() {
    const index = await getAssignedPersonaIndex();
    return getPersonaByIndex(index);
}
export async function cacheAssignedPersonaForContentScripts() {
    const persona = await getAssignedPersona();
    await chrome.storage.local.set({ [ASSIGNED_PERSONA_KEY]: persona });
}
export const ASSIGNED_PERSONA_STORAGE_KEY = ASSIGNED_PERSONA_KEY;
function generateInstallId() {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function hashToIndex(input, modulo) {
    let hash = 2166136261;
    for (let i = 0; i < input.length; i += 1) {
        hash ^= input.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
    }
    return Math.abs(hash) % modulo;
}
