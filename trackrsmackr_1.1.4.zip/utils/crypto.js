import { CryptoUtils } from './CryptoUtils.js';
export async function generateKey() {
    return CryptoUtils.generateKey();
}
export async function exportKey(key) {
    return CryptoUtils.exportKey(key);
}
export async function importKey(keyData) {
    return CryptoUtils.importKey(keyData);
}
export async function encryptData(data, key) {
    return CryptoUtils.encrypt(data, key);
}
export async function decryptData(encryptedData, key) {
    return CryptoUtils.decrypt(encryptedData, key);
}
