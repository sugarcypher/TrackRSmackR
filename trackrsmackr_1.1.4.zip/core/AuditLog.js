export class AuditLog {
    async log(entry) {
        const data = (await chrome.storage.local.get('auditLog'));
        const log = data.auditLog ?? [];
        log.push(entry);
        if (log.length > AuditLog.MAX_ENTRIES) {
            log.shift();
        }
        await chrome.storage.local.set({ auditLog: log });
    }
    async getHistory() {
        const data = (await chrome.storage.local.get('auditLog'));
        return data.auditLog ?? [];
    }
}
AuditLog.MAX_ENTRIES = 1000;
