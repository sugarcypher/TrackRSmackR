import { JarType } from '../workers/CookieJarWorker.js';
export class PolicyEngine {
    constructor() {
        this.userAllowlist = [];
        this.mode = 'BALANCED';
        this.trackingSignatures = ['_ga', '_gid', '_fbp', 'uid', 'tracker', 'ads'];
        this.essentialSignatures = ['session', 'auth', 'token', 'csrf'];
    }
    async init() {
        const stored = (await chrome.storage.local.get([
            'userAllowlist',
            'policyMode'
        ]));
        this.userAllowlist = Array.isArray(stored.userAllowlist)
            ? stored.userAllowlist.filter((domain) => typeof domain === 'string')
            : [];
        if (stored.policyMode === 'STRICT' || stored.policyMode === 'BALANCED') {
            this.mode = stored.policyMode;
        }
    }
    setModeForTesting(mode) {
        this.setMode(mode);
    }
    setMode(mode) {
        this.mode = mode;
    }
    setAllowlistForTesting(domains) {
        this.setAllowlist(domains);
    }
    setAllowlist(domains) {
        this.userAllowlist = [...domains];
    }
    getMode() {
        return this.mode;
    }
    evaluate(cookie, options) {
        const lowerName = cookie.name.toLowerCase();
        const lowerDomain = cookie.domain.toLowerCase();
        const effectiveMode = options?.modeOverride ?? this.mode;
        if (this.userAllowlist.some((domain) => lowerDomain.includes(domain.trim().toLowerCase()))) {
            return {
                action: 'ALLOW',
                reason: 'User Allowlisted',
                targetJar: JarType.VAULT
            };
        }
        if (this.essentialSignatures.some((sig) => lowerName.includes(sig))) {
            return {
                action: 'ALLOW',
                reason: 'Heuristic: Essential Session/Auth',
                targetJar: JarType.VAULT
            };
        }
        if (this.trackingSignatures.some((sig) => lowerName.includes(sig))) {
            return {
                action: 'QUARANTINE',
                reason: 'Signature Match: Known Tracker',
                targetJar: JarType.QUARANTINE
            };
        }
        return {
            action: effectiveMode === 'STRICT' ? 'QUARANTINE' : 'DECAY',
            reason: effectiveMode === 'STRICT'
                ? 'Policy: Unknown Cookie (Strict)'
                : 'Policy: Unknown Cookie (Decay)',
            targetJar: JarType.QUARANTINE
        };
    }
}
