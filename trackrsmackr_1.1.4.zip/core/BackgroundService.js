import { BouncerCore } from './BouncerCore.js';
import { enforceLocalOnlyRuntime } from './LocalOnlyGuard.js';
import { cacheAssignedPersonaForContentScripts, getOrCreateInstallId } from '../utils/PersonaSelector.js';
enforceLocalOnlyRuntime();
const bouncer = new BouncerCore();
void bouncer.start();
void (async () => {
    await getOrCreateInstallId();
    await cacheAssignedPersonaForContentScripts();
})();
const ONBOARDING_URL_PATH = 'static/onboarding.html';
async function openOnboarding() {
    try {
        await chrome.tabs.create({ url: chrome.runtime.getURL(ONBOARDING_URL_PATH) });
    }
    catch (error) {
        console.error('Failed to open onboarding tab', error);
    }
}
async function openOnboardingIfIncomplete() {
    const data = (await chrome.storage.local.get('onboardingComplete'));
    if (data.onboardingComplete !== true) {
        await openOnboarding();
    }
}
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason !== 'install') {
        return;
    }
    void openOnboarding();
});
chrome.runtime.onStartup.addListener(() => {
    void openOnboardingIfIncomplete();
});
