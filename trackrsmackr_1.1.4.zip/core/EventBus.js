function makeEventId() {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
        return crypto.randomUUID();
    }
    return `evt-${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
}
export class EventBus {
    constructor() {
        this.handlers = {};
    }
    subscribe(type, handler) {
        const bucket = this.handlers[type] ?? new Set();
        bucket.add(handler);
        this.handlers[type] = bucket;
        return () => {
            const current = this.handlers[type];
            if (!current) {
                return;
            }
            current.delete(handler);
            if (current.size === 0) {
                delete this.handlers[type];
            }
        };
    }
    async publish(type, source, payload, options) {
        const envelope = {
            id: makeEventId(),
            type,
            source,
            timestamp: Date.now(),
            confidence: Math.max(0, Math.min(1, options?.confidence ?? 1)),
            correlationId: options?.correlationId,
            payload
        };
        const listeners = this.handlers[type];
        if (!listeners || listeners.size === 0) {
            return envelope;
        }
        for (const listener of listeners) {
            await listener(envelope);
        }
        return envelope;
    }
}
