const BLOCKED_MESSAGE = 'TrackRSmackR local-only guard blocked a network API call from background context.';
export function enforceLocalOnlyRuntime() {
    if (typeof globalThis.fetch === 'function') {
        const originalFetch = globalThis.fetch;
        const blockedFetch = (async (..._args) => {
            throw new Error(BLOCKED_MESSAGE);
        });
        Object.assign(blockedFetch, originalFetch);
        globalThis.fetch = blockedFetch;
    }
}
