export function resolveTutorSwarmPolicyMode(summary, currentMode, floorMode = 'BALANCED') {
    const signal = summary.tutorSwarm?.signal;
    if (signal === 'SECURITY_ALERT' ||
        signal === 'INTERVENE_HALT' ||
        signal === 'INTERVENE_ROLLBACK' ||
        signal === 'INTERVENE_ADJUST_PARAMS') {
        const desiredMode = 'STRICT';
        return {
            desiredMode,
            shouldApply: desiredMode !== currentMode,
            reason: `Swarm signal ${signal} raised risk posture`
        };
    }
    const canRelaxToBalanced = signal === 'CONTINUE' &&
        summary.posture !== 'ELEVATED' &&
        summary.trend !== 'RISING' &&
        summary.score < 8;
    if (canRelaxToBalanced) {
        const desiredMode = floorMode === 'STRICT' ? 'STRICT' : 'BALANCED';
        return {
            desiredMode,
            shouldApply: desiredMode !== currentMode,
            reason: floorMode === 'STRICT'
                ? 'Swarm relaxation blocked by strict policy floor'
                : 'Swarm signal CONTINUE with stable trend'
        };
    }
    return {
        desiredMode: currentMode,
        shouldApply: false,
        reason: 'Autopilot held current policy mode'
    };
}
